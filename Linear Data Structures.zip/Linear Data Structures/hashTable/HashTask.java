package hashTable;

import java.util.Random;

public class HashTask {
	
	public static String GenerateRandomString(int length) {
		String pattern="abcdxyz";
		String string="";
		Random ran=new Random();
		for(int i=0;i<length;i++)
			string=string+pattern.charAt(ran.nextInt(pattern.length()));
		return string;
	}
	
	public static void RunHashCuckoo(int num, int j) {
	
		long start, end;
		CuckooHashTable<String> H = new CuckooHashTable<>( new StringHashFamily( 3 ), num);		
		
		start = System.nanoTime( );
	    for( int k = 0; k < num; k++)
	    	H.insert( GenerateRandomString(10) );
	    end = System.nanoTime( );
	    System.out.println("Average Time of each Insertion in Cuckoo when i="+j+": "+(end-start)/num);    
		
	    start = System.nanoTime( );
		for( int k = 0; k < num; k++) 
	    	H.contains(GenerateRandomString(10));
	   end = System.nanoTime( );
	    System.out.println("Average Time of each Search in Cuckoo when i="+j+": "+(end-start)/num);
		
	    String s="";
		for( int k = 0; k < num; k++) {
	    	s=GenerateRandomString(10);
	    	if(H.contains(s))
	    		 H.remove(s);
		}
	}
	public static void RunHashQuadraticProbing(int num, int j) {
		long start, end;
		
		QuadraticProbingHashTable<String> H = new QuadraticProbingHashTable<>( );	
		
		start = System.nanoTime( );
	    for( int k = 0; k < num; k++)
	    	H.insert( GenerateRandomString(10) );
	    end = System.nanoTime( );
	    System.out.println("Average Time of each Insertion in QuadraticProbing when i="+j+": "+(end-start)/num);    
		
	    start = System.nanoTime( );
		for( int k = 0; k < num; k++) 
	    	H.contains(GenerateRandomString(10));
		end = System.nanoTime( );
	    System.out.println("Average Time of each Search in QuadraticProbing when i="+j+": "+(end-start)/num);
		
	    String s="";
		for( int k = 0; k < num; k++) {
	    	s=GenerateRandomString(10);
	    	if(H.contains(s))
	    		 H.remove(s);
		}		
		
	}
	public static void RunHashSeperateChaining(int num, int j) {
		
		long start, end;
		
		SeparateChainingHashTable<String> H = new SeparateChainingHashTable<>( );
		
		start = System.nanoTime( );
	    for( int k = 0; k < num; k++)
	    	H.insert( GenerateRandomString(10) );
	    end = System.nanoTime( );
	    System.out.println("Average Time of each Insertion in SeparateChaining when i="+j+": "+(end-start)/num);    
		
	    start = System.nanoTime( );
		for( int k = 0; k < num; k++) 
	    	H.contains(GenerateRandomString(10));
		end = System.nanoTime( );
	    System.out.println("Average Time of each Search in SeparateChaining when i="+j+": "+(end-start)/num);
		
	    String s="";
		for( int k = 0; k < num; k++) {
	    	s=GenerateRandomString(10);
	    	if(H.contains(s))
	    		 H.remove(s);
		}
	}
	
	public static void main(String[] args) {
		
		for(int i=1;i<=20;i++) {
			int n=(int)Math.pow(2, i);
			
			RunHashCuckoo(n,i);              //Operations for Cuckoo.
			RunHashQuadraticProbing(n,i);    //Operations for QuadraticProbing
			RunHashSeperateChaining(n,i);    //Operations for SeperateChaining
		}
		System.out.println("Note: Time is in nanoseconds");
	}

}
