package sorting;

import java.util.ArrayList;
import sorting.*;
import java.util.List;
import java.util.Arrays;
import java.util.Random;

public class RadixSort
{
    /*
     * Radix sort an array of Strings
     * Assume all are all ASCII
     * Assume all have same length
     */
    public static void radixSortA( String [ ] arr, int stringLen )
    {
        final int BUCKETS = 256;
        
        ArrayList<ArrayList<String>> buckets = new ArrayList<ArrayList<String>>(BUCKETS);
        //ArrayList<String[]> buckets = new ArrayList<String[]>(BUCKETS);
        
        for( int i = 0; i < BUCKETS; i++ )
        	//this.get(index).add(element);
        	//ArrayList<String> element = new ArrayList<String>();
        	buckets.add(new ArrayList<String>());
        	//buckets.set(i, new ArrayList<String>());
            //buckets[i] = new ArrayList<String>();
        
        for( int pos = stringLen - 1; pos >= 0; pos-- )
        {
            for( String s : arr )
                //buckets[ s.charAt( pos ) ].add( s );
            	buckets.get(s.charAt(pos)).add(s);

            int idx = 0;
            for( ArrayList<String> thisBucket : buckets )
            {
                for( String s : thisBucket )
                    arr[ idx++ ] = s;
                
                thisBucket.clear( );
            }
        }
    }
       
    /*
     * Counting radix sort an array of Strings
     * Assume all are all ASCII
     * Assume all have same length
     */
    public static void countingRadixSort( String [ ] arr, int stringLen )
    {
        final int BUCKETS = 256;
        
        int N = arr.length;
        String [ ] buffer = new String[ N ];

        String [ ] in = arr;
        String [ ] out = buffer;
        
        for( int pos = stringLen - 1; pos >= 0; pos-- )
        {
            int[ ] count = new int [ BUCKETS + 1 ];
            
            for( int i = 0; i < N; i++ )
                count[ in[ i ].charAt( pos ) + 1 ]++;

            for( int b = 1; b <= BUCKETS; b++ )
                count[ b ] += count[ b - 1 ];

            for( int i = 0; i < N; i++ )
                out[ count[ in[ i ].charAt( pos ) ]++ ] = in[ i ];
            
              // swap in and out roles
            String [ ] tmp = in;
            in = out;
            out = tmp;
        }
        
           // if odd number of passes, in is buffer, out is arr; so copy back
        if( stringLen % 2 == 1 )
            for( int i = 0; i < arr.length; i++ )
                out[ i ] = in[ i ];
    }
    
    /*
     * Radix sort an array of Strings
     * Assume all are all ASCII
     * Assume all have length bounded by maxLen
     */
    /*
    public static void radixSort( String [ ] arr, int maxLen )
    {
        final int BUCKETS = 256;
        
        ArrayList<String> [ ] wordsByLength = new ArrayList<>[ maxLen + 1 ];
        ArrayList<String> [ ] buckets = new ArrayList<>[ BUCKETS ];
        
        for( int i = 0; i < wordsByLength.length; i++ )
            wordsByLength[ i ] = new ArrayList<>( );
        
        for( int i = 0; i < BUCKETS; i++ )
            buckets[ i ] = new ArrayList<>( );
        
        for( String s : arr )
            wordsByLength[ s.length( ) ].add( s );
       
        int idx = 0;
        for( ArrayList<String> wordList : wordsByLength )
            for( String s : wordList )
                arr[ idx++ ] = s;
        
        int startingIndex = arr.length;    
        for( int pos = maxLen - 1; pos >= 0; pos-- )
        {
            startingIndex -= wordsByLength[ pos + 1 ].size( );
            
            for( int i = startingIndex; i < arr.length; i++ )
                buckets[ arr[ i ].charAt( pos ) ].add( arr[ i ] );
            
            idx = startingIndex;
            for( ArrayList<String> thisBucket : buckets )
            {
                for( String s : thisBucket )
                    arr[ idx++ ] = s;
                
                thisBucket.clear( );
            }
        }
    }*/

    // Print the array
    private static void print( String[] a)
    {
        for( int i = 0; i < a.length; i++ )
        	System.out.print(a[i] + " ");
        System.out.println();
    }
    

    // Do some tests
    // Note: radix sort works only for fixed length strings (radixSortA)
    // For variable length strings, radixSort has to be modified
    public static void main( String [ ] args )
    {
        
        Random r = new Random( );
        int LEN;
        for(int l=2;l<6;l++) {
        	LEN=l*2;	
        System.out.println("For Sting Size: "+LEN);
        long merge=0, heap=0, quick=0, dual=0, radix=0;
        for(int k=0; k<10;k++) {
        	List<String> lst = new ArrayList<>( );
        	
        	for( int i = 0; i < 100000; i++ ){
        		String str = "";
        		int len = LEN; //3 + r.nextInt( 7 ); // between 3 and 9 characters

        		for( int j = 0; j < len; j++ )
        			str += (char) ( 'a' + r.nextInt( 26 ) );
        		lst.add( str );
        	}

        String [ ] arr1 = new String[ lst.size( ) ];
        String [ ] arr2 = new String[ lst.size( ) ];
        String [ ] arr3 = new String[ lst.size( ) ];
        String [ ] arr4 = new String[ lst.size( ) ];
        String [ ] arr5 = new String[ lst.size( ) ];
        
        lst.toArray( arr1 );
        lst.toArray( arr2 );
        lst.toArray( arr3 );
        lst.toArray( arr4 );
        lst.toArray( arr5 );
     
        
        // Print unsorted array
        // print(arr1);
       
        long start, end;
        start = System.currentTimeMillis( );
        Sort.mergeSort( arr1 );
        end = System.currentTimeMillis( );
        merge = merge +(end - start);

        start = System.currentTimeMillis( );
        Sort.heapsort( arr2 );
        end = System.currentTimeMillis( );
        heap=heap+ (end - start);
        
        start = System.currentTimeMillis( );
        Sort.quicksort(arr3);
        end = System.currentTimeMillis( );
        quick=quick+(end - start);
        
        start = System.currentTimeMillis( );
        Arrays.sort( arr4 );
        end = System.currentTimeMillis( );
        dual=dual+(end - start);

        start = System.currentTimeMillis( );
        radixSortA( arr5, LEN );
        end = System.currentTimeMillis( );
        radix=radix+(end - start);
      }
        
        
      System.out.println("Average time of Merge Sort: "+(merge)/10);
      System.out.println("Average time of Heap Sort: "+(heap)/10);
      System.out.println("Average time of Quick Sort: "+(quick)/10);
      System.out.println("Average time of Dual Pivot Sort: "+(dual)/10);
      System.out.println("Average time of Radix Sort: "+(radix)/10);
        }  	
  /**      for( int i = 0; i < arr1.length; i++ )
            if( !arr1[ i ].equals( arr2[ i ]  ) )
                System.out.println( "OOPS!!" );
        
        // Print sorted array
        //print(arr2);**/
    }
    
}
