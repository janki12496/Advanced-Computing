package searchtrees;

import java.util.Random;

public class KeysInOrder {

	public static void runBinaryTree(int n) {
		long start, end;
		Random random = new Random();
		BinarySearchTree<Integer> t = new BinarySearchTree<>();

		start = System.nanoTime();
		for (int i = 1; i <= n; i++) {
			t.insert(i);
		}
		end = System.nanoTime();
		System.out.println("Average time of insterions in Binary tree:" + (end-start) / n);

		start = System.nanoTime();
		for (int i = 1; i <= n; i++) {
			if (!t.contains(random.nextInt(100000) + 1))
				System.out.println("key " + i + " not found");
		}
		end = System.nanoTime();
		System.out.println("Average time of search in Binary tree:" + ( end-start) / n);

		start = System.nanoTime();
		for (int i = n; i >= 1; i--) {
			if(t.contains( i))
			t.remove(i);
		}
		end = System.nanoTime();
		System.out.println("Average time of deletions in Binary tree:" + (end-start) / n);
	//	System.out.println("Tree after removals:");
		t.printTree();
	}

	public static void runAVLTree(int n) {
		long start, end;
		Random random = new Random();
		AVLTree<Integer> t = new AVLTree<>();
		start = System.nanoTime();
		for (int i = 1; i <= n; i++) {
			t.insert(i);
		}
		end = System.nanoTime();
		System.out.println("Average time of insterions in AVL Tree: " + (end-start) / n);
		// t.printTree( );

		start = System.nanoTime();
		for (int i = 1; i <= n; i++) {
			if (!t.contains(random.nextInt(100000) + 1))
				System.out.println("key " + i + " not found");
		}
		end = System.nanoTime();
		System.out.println("Average time of search in AVL Tree: " + (end-start) / n);

		start = System.nanoTime();
		for (int i = n; i >= 1; i--) {
			if(t.contains( i))
			t.remove(i);
		}
		end = System.nanoTime();
		System.out.println("Average time of deletionsin AVL Tree: " + (end-start) / n);
		System.out.println("Tree after removals:");
		t.printTree();
	}

	public static void runRedBlackBST(int n) {
		long start, end;
		Random random = new Random();
		RedBlackBST<Integer, Integer> t = new RedBlackBST<Integer, Integer>();

		start = System.nanoTime();
		for (int i = 1; i <= n; i++) {
			t.put(i, i);
		}
		end = System.nanoTime();
		System.out.println("Average time of insterions in RedblackBST: " + (end-start) / n);
	//	 t.printTree( );

		start = System.nanoTime();
		for (int i = 1; i <= n; i++) {
			if (t.get(random.nextInt(100000)+1) == null)
				System.out.println("key " + i + " not found");
		}
		end = System.nanoTime();
		System.out.println("Average time of search in RedblackBST: " + (end-start) / n);

		start = System.nanoTime();
		for (int i = n; i >= 1; i--) {
			 if(t.contains( i))
	    		 t.delete(i);
		}
		end = System.nanoTime();
		System.out.println("Average time of deletions in RedblackBST: " + (end-start) / n);
	//	System.out.println("Tree after removals:");
		t.printTree();
	}

	public static void runSplayTree(int n) {
		long start,end; 
		Random random= new Random();
		SplayTree<Integer> t = new SplayTree<Integer>( );
		
		start=System.nanoTime();
		for( int i = 1; i <= n; i++)
	    {
			t.insert(i);
	    }
		end=System.nanoTime();
		System.out.println( "Average time of insterions in Splay Tree: "+(end-start)/n );
	    // t.printTree( );

		start=System.nanoTime(); 
		for( int i = 1; i <= n; i++)
	    {
	   	 if (!t.contains(random.nextInt(100000)+1))
	   		 System.out.println("key " + i + " not found" );
	    }
	    end=System.nanoTime();
		System.out.println( "Average time of search in Splay Tree: "+(end-start)/n );
		
		start=System.nanoTime(); 
		for( int i = n; i >= 1; i-- )
	     {
			if(t.contains( i)) 
			t.remove( i );
	     }
		end=System.nanoTime();
		System.out.println( "Average time of deletions in Splay Tree: "+(end-start)/n );
	    System.out.println( "Tree after removals:" );
	    t.printTree( );
	}

	public static void main(String[] args) {
		final int num = 100000;
	//	runBinaryTree(num);
	//	runAVLTree(num);
	//	runRedBlackBST(num);
		runSplayTree(num);
	}

}
