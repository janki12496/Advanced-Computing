package searchtrees;

import java.util.Random;

public class KeysRandom {
	
	public static void runBinarySearch(int []insert,int []search,int []delete, int len) {
		BinarySearchTree<Integer> t = new BinarySearchTree<>( );
		long start, end;

	  //  System.out.println( "Create the tree..." );
	    start=System.nanoTime( );
	    for( int i = 0; i < len; i++)
	    {
	    	t.insert( insert[i] );
	    }
	    end=System.nanoTime( );
	    System.out.println("Average time of each insertion in BinarySearch Tree: "+(end-start)/len);
	   
	 //   t.printTree( );
	     
	    start=System.nanoTime( );
	    for( int i = 0; i < len; i++)
	    {
	    	if (!t.contains( search[i]))
	    		 System.out.println("key not found" );
	    }
	    end=System.nanoTime( );
	    System.out.println("Average time of each search in BinarySearch Tree: "+(end-start)/len);

	    start=System.nanoTime( );
	    for( int i = 0; i < len; i++ )
	    {
	    	if(t.contains(delete[i]))
	    	t.remove( delete[i] );
	    }
	    end=System.nanoTime( );
	    System.out.println("Average time of each deletion in BinarySearch Tree: "+(end-start)/len);

	    t.printTree( );
	}
	public static void runAVL(int []insert,int []search,int []delete, int len) {
		AVLTree<Integer> t = new AVLTree<>( );
	    long start, end;
	   // System.out.println( "Create the tree..." );
	    start=System.nanoTime( );
	    for( int i = 0; i < len; i++)
	    {
	    	t.insert( insert[i] );
	    }
	    end=System.nanoTime( );
	    System.out.println("Average time of each insertion in AVL Tree: "+(end-start)/len);
	   
	   //t.printTree( );
	     
	     start=System.nanoTime( );
	     for( int i = 0; i <len; i++)
	     {
	    	 if (!t.contains( search[i]))
	    		 System.out.println("key not found" );
	     }
	     end=System.nanoTime( );
	     System.out.println("Average time of each search in AVL Tree: "+(end-start)/len);

	     start=System.nanoTime( );
	     for( int i = 0; i < len; i++ )
	     {
	    	 if(t.contains(delete[i]))
	    	 t.remove( delete[i] );
	     }
	     end=System.nanoTime( );
	     System.out.println("Average time of each deletion in AVL Tree: "+(end-start)/len);
	     t.printTree( );
	}
	public static void runRedBlackBST(int []insert,int []search,int []delete, int len) {
		RedBlackBST<Integer, Integer> t = new RedBlackBST<Integer, Integer>();
	    long start, end;
	 //   Random random = new Random();
	    System.out.println( "Create the tree..." );
	    
	    start=System.nanoTime( );
	    for( int i = 0; i < len; i++)
	    {
	    	t.put( insert[i],insert[i] );
	    }
	    end=System.nanoTime( );
	    System.out.println("Average time of each insertion in RedBlackBST: "+(end-start)/len);
	    
	    start=System.nanoTime( );
	     for( int i = 0; i < len; i++)
	     {
	    	 if (t.get(search[i])== null) 
	    		 System.out.println("key " + search[i] + " not found" );
	     }
	     end=System.nanoTime( );
	     System.out.println("Average time of each search in RedBlackBST: "+(end-start)/len);

	     start=System.nanoTime( );
	     for( int i = 0; i < len; i++ )
	     {
	     if(t.contains(delete[i]))
	    		 t.delete( delete[i] );
	     }
	     end=System.nanoTime( );
	     System.out.println("Average time of each deletion in RedBlackBST: "+(end-start)/len);
	     t.printTree( );
	}
	public static void runSplayTree(int []insert,int []search,int []delete, int len) {
		SplayTree<Integer> t = new SplayTree<Integer>( );
	    long start, end;
	    System.out.println( "Create the tree..." );
	    start=System.nanoTime( );
	    for( int i = 0; i < len; i++)
	    {
	    	t.insert( insert[i] );
	    }
	    end=System.nanoTime( );
	    System.out.println("Average time of each insertion in SplayTree: "+(end-start)/len);
	   
	   //t.printTree( );
	     
	     start=System.nanoTime( );
	     for( int i = 0; i < len; i++)
	     {
	    	 if (!t.contains( search[i]))
	    		 System.out.println("key not found" );
	     }
	     end=System.nanoTime( );
	     System.out.println("Average time of each search in SplayTree: "+(end-start)/len);

	     start=System.nanoTime( );
	     for( int i = 0; i < len; i++ )
	     {
	    	 if(t.contains(delete[i]))
	    	 t.remove( delete[i] );
	     }
	     end=System.nanoTime( );
	     System.out.println("Average time of each deletion in SplayTree: "+(end-start)/len);
	     t.printTree( );
	}
	public static void main(String[] args) {
		
		int num=100000;
		int[]insert=new int[num];
		int[]search=new int[num];
		int[]delete=new int[num];
		Random ran=new Random();
		for(int j=0; j<num; j++) {
			insert[j]=ran.nextInt(10000)+1;
			search[j]=ran.nextInt(10000)+1;
			delete[j]=ran.nextInt(10000)+1;
		}
		
	//	runBinarySearch(insert,search,delete,num);
	//	runAVL(insert,search,delete,num);
	//	runRedBlackBST(insert,search,delete,num);
		runSplayTree(insert,search,delete,num);
	}
		
}
